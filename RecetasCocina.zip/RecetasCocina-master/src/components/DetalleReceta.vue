<template>
  <div :class="['receta-container']">
    <h1 :class="['receta-title']">{{ receta?.nombre }}</h1>
    <div :class="['receta-image-container']">
      <img :src="receta?.imagen" alt="Imagen de la receta" :class="['receta-image']">
    </div>
    
    <h3 :class="['receta-subtitle', 'is-clickable']" @click="toggleSection('showDescripcion')">
      Descripción
    </h3>
    <p :class="['receta-descripcion', { 'is-hidden': !showDescripcion }]">
      {{ receta?.descripcion }}
    </p>
    
    <h3 :class="['receta-subtitle', 'is-clickable']" @click="toggleSection('showIngredientes')">
      Ingredientes
    </h3>
    <div :class="['receta-section', { 'is-hidden': !showIngredientes }]">
      <ul :class="['receta-list']">
        <li v-for="ingrediente in receta?.ingredientes" :key="ingrediente" :class="['receta-item']">{{ ingrediente }}</li>
      </ul>
    </div>
    
    <h3 :class="['receta-subtitle', 'is-clickable']" @click="toggleSection('showPasos')">
      Pasos
    </h3>
    <div :class="['receta-section', { 'is-hidden': !showPasos }]">
      <ol :class="['receta-list']">
        <li v-for="paso in receta?.pasos" :key="paso" :class="['receta-item']">{{ paso }}</li>
      </ol>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      receta: null,
      showDescripcion: false,
      showIngredientes: false,
      showPasos: false
    };
  },
  created() {
    this.fetchReceta();
  },
  methods: {
    async fetchReceta() {
      try {
        const id = this.$route.params.id;
        const response = await axios.get(`https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas/${id}`);
        this.receta = response.data;
      } catch (error) {
        console.error(error);
      }
    },
    toggleSection(section) {
      this[section] = !this[section];
    }
  }
};
</script>

<style scoped>
.receta-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.receta-title {
  font-size: 2.5rem;
  text-align: center;
  margin-bottom: 20px;
}

.receta-image-container {
  text-align: center;
  margin-bottom: 20px;
}

.receta-image {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
}

.receta-descripcion {
  font-size: 1.4rem;
  line-height: 1.8;
  margin-bottom: 20px;
  color: #555;
}

.receta-section {
  margin-bottom: 30px;
}

.receta-subtitle {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 10px;
}

.is-clickable {
  cursor: pointer;
  color: blue;
}

.is-hidden {
  display: none;
}

.receta-list {
  list-style: none;
  padding: 0;
}

.receta-item {
  font-size: 1.6rem;
  line-height: 1.6;
  margin-bottom: 8px;
  color: #555;
}

@media (max-width: 600px) {
  .receta-title {
    font-size: 2rem;
  }
  
  .receta-subtitle {
    font-size: 1.6rem;
  }
  
  .receta-item {
    font-size: 1.4rem;
  }
}
</style>
