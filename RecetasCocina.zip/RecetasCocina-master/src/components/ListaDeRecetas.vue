<template>
  <div class="container mt-5">
    <h2 class="recetas-title">Lista de Recetas</h2>
    <h3 class="recetas-subtitle">Cantidad de Recetas: <span v-text="contarCantidadRecetas"></span></h3>

    <ul class="recetas-list">
      <li v-for="receta in recetas" :key="receta.id" class="receta-item">
        <router-link :to="'/receta/' + receta.id" class="receta-link">{{ receta.nombre }}</router-link>
        <div class="receta-actions">
          <img v-if="receta.imagen" :src="receta.imagen" alt="Imagen de la receta" class="receta-image">
          <button @click="eliminarReceta(receta.id)" class="btn btn-danger">Eliminar</button>
          <button @click="marcarFavorita(receta)" :class="{'btn': true, 'btn-primary': !receta.esFavorita, 'btn-secondary': receta.esFavorita}">
            {{ receta.esFavorita ? 'Quitar de Favoritas' : 'Marcar Favorita' }}
          </button>
          <button @click="abrirModalEditar(receta)" class="btn btn-warning">Editar</button>
        </div>
      </li>
    </ul>

    <div class="recetas-favoritas">
      <h3 class="recetas-subtitle mt-4">Recetas Favoritas</h3>
      <ul v-if="recetasFavoritas.length > 0" class="recetas-list">
        <li v-for="receta in recetasFavoritas" :key="receta.id" class="receta-item">
          <router-link :to="'/receta/' + receta.id" class="receta-link">{{ receta.nombre }}</router-link>
        </li>
      </ul>
      <p v-else class="recetas-empty">No hay recetas favoritas.</p>
    </div>

    <div v-if="mostrarModalEditar" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Editar Receta</h5>
            <button type="button" class="close" @click="cerrarModalEditar" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="guardarEdicion">
              <div class="form-group">
                <label for="nombreReceta">Nombre</label>
                <input type="text" class="form-control" id="nombreReceta" v-model="recetaEditando.nombre" required>
              </div>
              <div class="form-group">
                <label for="descripcionReceta">Descripción</label>
                <textarea class="form-control" id="descripcionReceta" v-model="recetaEditando.descripcion" required></textarea>
              </div>
              <div class="form-group">
                <label for="ingredientesReceta">Ingredientes</label>
                <textarea class="form-control" id="ingredientesReceta" v-model="recetaEditando.ingredientes" required></textarea>
              </div>
              <div class="form-group">
                <label for="pasosReceta">Pasos</label>
                <textarea class="form-control" id="pasosReceta" v-model="recetaEditando.pasos" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Guardar</button>
              <button type="button" class="btn btn-secondary" @click="cerrarModalEditar">Cancelar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      recetas: [],
      recetasFavoritas: [],
      mostrarModalEditar: false,
      recetaEditando: {}
    };
  },
  beforeMount() {
    this.cargarRecetas();
  },
  methods: {
    async cargarRecetas() {
      try {
        const response = await axios.get('https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas');
        this.recetas = response.data;
        this.recetasFavoritas = this.recetas.filter(receta => receta.esFavorita);
      } catch (error) {
        console.error('Error al cargar las recetas:', error);
      }
    },
    async eliminarReceta(id) {
      try {
        await axios.delete(`https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas/${id}`);
        this.recetas = this.recetas.filter(receta => receta.id !== id);
        this.recetasFavoritas = this.recetas.filter(receta => receta.esFavorita);
      } catch (error) {
        console.error('Error al eliminar la receta:', error);
      }
    },
    async marcarFavorita(receta) {
      try {
        receta.esFavorita = !receta.esFavorita;
        await axios.put(`https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas/${receta.id}`, receta);
        this.recetasFavoritas = this.recetas.filter(receta => receta.esFavorita);
      } catch (error) {
        console.error('Error al marcar la receta como favorita:', error);
      }
    },
    abrirModalEditar(receta) {
      this.recetaEditando = { ...receta };
      this.mostrarModalEditar = true;
    },
    cerrarModalEditar() {
      this.mostrarModalEditar = false;
      this.recetaEditando = {};
    },
    async guardarEdicion() {
      try {
        await axios.put(`https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas/${this.recetaEditando.id}`, this.recetaEditando);
        this.cargarRecetas();
        this.cerrarModalEditar();
      } catch (error) {
        console.error('Error al guardar la edición de la receta:', error);
      }
    }
  },
  computed: {
    contarCantidadRecetas() {
      return this.recetas.length;
    }
  }
};
</script>

<style scoped>
.recetas-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f7f7f7;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.recetas-title {
  font-size: 2.5rem;
  text-align: center;
  margin-bottom: 20px;
  color: #333;
}

.recetas-subtitle {
  font-size: 1.6rem;
  margin-bottom: 10px;
  color: #555;
}

.recetas-list {
  list-style: none;
  padding: 0;
}

.receta-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  border-bottom: 1px solid #eee;
}

.receta-link {
  font-size: 1.8rem;
  color: #333;
  text-decoration: none;
  transition: color 0.3s;
}

.receta-link:hover {
  color: #007bff;
}

.receta-image {
  max-width: 80px;
  height: auto;
  border-radius: 4px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
}

.receta-actions {
  display: flex;
  align-items: center;
}

.btn {
  font-size: 1.4rem;
  margin-left: 10px;
}

.recetas-favoritas {
  margin-top: 30px;
}

.recetas-empty {
  font-style: italic;
  color: #777;
}

.modal {
  display: block;
  position: fixed;
  z-index: 1050;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: hidden;
  outline: 0;
  background: rgba(0, 0, 0, 0.5);
}

.modal-dialog {
  position: relative;
  width: auto;
  margin: 10px;
  pointer-events: none;
}

.modal-content {
  position: relative;
  display: flex;
  flex-direction: column;
  width: 100%;
  pointer-events: auto;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0, 0, 0, 0.2);
  border-radius: 0.3rem;
  outline: 0;
}

.modal-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 1rem 1rem;
  border-bottom: 1px solid #dee2e6;
  border-top-left-radius: 0.3rem;
  border-top-right-radius: 0.3rem;
}

.modal-title {
  margin-bottom: 0;
  line-height: 1.5;
}

.close {
  padding: 0;
  background-color: transparent;
  border: 0;
}

.modal-body {
  position: relative;
  flex: 1 1 auto;
  padding: 1rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-control {
  display: block;
  width: 100%;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.btn-primary {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}

.btn-secondary {
  color: #fff;
  background-color: #6c757d;
  border-color: #6c757d;
}

.btn-warning {
  color: #212529;
  background-color: #ffc107;
  border-color: #ffc107;
}
</style>
