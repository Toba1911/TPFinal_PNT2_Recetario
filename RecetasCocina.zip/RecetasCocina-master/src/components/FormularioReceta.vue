<template>
  <div class="container mt-5">
    <h2>Agregar Receta</h2>
    <form @submit.prevent="submitForm" class="mb-5">
      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input
          type="text"
          class="form-control"
          id="nombre"
          v-model="receta.nombre"
          @input="validateNombre"
        />
        <div v-if="nombreError" class="text-danger">{{ nombreError }}</div>
      </div>

      <div class="mb-3">
        <label for="descripcion" class="form-label">Descripción</label>
        <textarea
          class="form-control"
          id="descripcion"
          v-model="receta.descripcion"
          @input="validateDescripcion"
        ></textarea>
        <div v-if="descripcionError" class="text-danger">{{ descripcionError }}</div>
      </div>

      <div class="mb-3">
        <label for="ingredientes" class="form-label">Ingredientes</label>
        <input
          type="text"
          class="form-control"
          id="ingredientes"
          v-model="nuevoIngrediente"
          @keyup.enter="agregarIngrediente"
        />
        <ul>
          <li v-for="(ingrediente, index) in receta.ingredientes" :key="index">{{ ingrediente }}</li>
        </ul>
        <div v-if="ingredientesError" class="text-danger">{{ ingredientesError }}</div>
      </div>

      <div class="mb-3">
        <label for="pasos" class="form-label">Pasos</label>
        <input
          type="text"
          class="form-control"
          id="pasos"
          v-model="nuevoPaso"
          @keyup.enter="agregarPaso"
        />
        <ul>
          <li v-for="(paso, index) in receta.pasos" :key="index">{{ paso }}</li>
        </ul>
        <div v-if="pasosError" class="text-danger">{{ pasosError }}</div>
      </div>

      <div class="mb-3">
        <label for="imagen" class="form-label">Imagen (opcional)</label>
        <input
          type="text"
          class="form-control"
          id="imagen"
          v-model="receta.imagen"
        />
      </div>

      <button 
        type="submit"
        class="btn btn-success my-3" 
        :disabled="validarBotonEnvio"
      >Agregar Receta</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      receta: {
        nombre: '',
        descripcion: '',
        ingredientes: [],
        pasos: [],
        imagen: ''
      },
      nuevoIngrediente: '',
      nuevoPaso: '',
      nombreError: '',
      descripcionError: '',
      ingredientesError: '',
      pasosError: ''
    };
  },
  methods: {
    validateCampo(valor, campo, error) {
      this[campo] = '';
      if (!valor) {
        this[campo] = error;
      } else if (valor.length < 2) {
        this[campo] = `El ${campo} debe tener al menos 2 caracteres.`;
      }
    },
    validateNombre() {
      this.validateCampo(this.receta.nombre, 'nombreError', 'El nombre es requerido.');
    },
    validateDescripcion() {
      this.validateCampo(this.receta.descripcion, 'descripcionError', 'La descripción es requerida.');
    },
    validateIngredientes() {
      this.ingredientesError = '';
      if (this.receta.ingredientes.length === 0) {
        this.ingredientesError = 'Debe agregar al menos un ingrediente.';
      }
    },
    validatePasos() {
      this.pasosError = '';
      if (this.receta.pasos.length === 0) {
        this.pasosError = 'Debe agregar al menos un paso.';
      }
    },
    agregarCampo(campo, valor, error) {
      if (valor) {
        this.receta[campo].push(valor);
        this[campo] = '';
        this.validateIngredientes();
      }
    },
    agregarIngrediente() {
      this.agregarCampo('ingredientes', this.nuevoIngrediente, 'Debe ingresar un ingrediente.');
    },
    agregarPaso() {
      this.agregarCampo('pasos', this.nuevoPaso, 'Debe ingresar un paso.');
    },
    async submitForm() {
      this.validateNombre();
      this.validateDescripcion();
      this.validateIngredientes();
      this.validatePasos();

      if (!this.nombreError && !this.descripcionError && !this.ingredientesError && !this.pasosError) {
        try {
          const response = await axios.post('https://66663bb1a2f8516ff7a2e4b0.mockapi.io/recetas', this.receta);
          console.log('Receta enviada:', response.data);

          this.receta.nombre = '';
          this.receta.descripcion = '';
          this.receta.ingredientes = [];
          this.receta.pasos = [];
          this.receta.imagen = '';

          this.$emit('recetaAgregada', response.data); 
        } catch (error) {
          console.error('Error al enviar la receta:', error);
        }
      } else {
        console.log('Corrige los errores antes de enviar la receta.');
      }
    }
  },
  computed: {
    validarBotonEnvio() {
      return (
        !!this.nombreError ||
        !!this.descripcionError ||
        !!this.ingredientesError ||
        !!this.pasosError ||
        !this.receta.nombre ||
        !this.receta.descripcion ||
        this.receta.nombre.length < 2 ||
        this.receta.descripcion.length < 2 ||
        this.receta.ingredientes.length === 0 ||
        this.receta.pasos.length === 0
      );
    }
  }
};
</script>

<style scoped>
.container {
  max-width: 600px;
}
</style>
